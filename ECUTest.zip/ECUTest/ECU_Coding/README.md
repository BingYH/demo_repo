# ECU Coding Package Workspace

This workspace supports the functionally equivalent migration of ECU-TEST `.pkg` libraries and test cases from SOP25 to SOP30. Start with [PROJECT_INSTRUCTIONS.md](PROJECT_INSTRUCTIONS.md), then use the material in `Instructions` to identify and validate each migration.

