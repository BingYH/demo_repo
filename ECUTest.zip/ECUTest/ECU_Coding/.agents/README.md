# Agent Configuration

Reserved for workspace-specific agent configuration and guidance. Project work must follow `PROJECT_INSTRUCTIONS.md` at the workspace root.

