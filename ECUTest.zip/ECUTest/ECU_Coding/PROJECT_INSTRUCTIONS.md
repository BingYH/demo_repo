# ECU Coding Package Migration — Project Instructions

## Project purpose

This workspace is used to create ECU-TEST packages for the ECU Coding topic for SOP30. Every SOP30 package is derived from an identified SOP25 reference package.

## Package model

ECU-TEST packages use the `.pkg` file format and are divided into two main categories:

- **Library packages** provide reusable functionality. A library package may depend on one or more other library packages.
- **Testcase packages** contain test cases and may use multiple library packages.

Dependencies can therefore be nested. When migrating a package, all referenced library packages and their transitive dependencies must be considered.

## Migration principle

The SOP30 package must provide the same functionality as its SOP25 reference package. This is a migration and adaptation task, not a redesign.

- Use the relation map in `Instructions/RelationMap_SOP25to30` to determine which SOP25 package is the reference for each SOP30 package.
- Preserve the reference package's behavior, test intent, execution flow, interfaces, and dependency relationships unless an explicit SOP30 requirement says otherwise.
- Do not invent or add new ECU-TEST elements merely to recreate existing functionality in a different way.
- Apply only the changes required for SOP30 compatibility, naming, configuration, dependencies, conventions, and acceptance criteria.
- The generated package must satisfy the ECU-TEST package PR checks and the customer's expectations.

## Authoritative inputs

Before creating or changing a package, consult the relevant material under `Instructions`:

1. `ECUTest_Help_official` for official ECU-TEST guidance.
2. `Test_Style_Guide` for project-specific structure, naming, and quality rules.
3. `RelationMap_SOP25to30` for the explicit SOP25-to-SOP30 package mapping.

If these sources conflict or a mapping is missing or ambiguous, do not guess. Record the issue and request clarification before producing the affected SOP30 package.

## Required workflow

For each SOP30 package:

1. Identify its package category and mapped SOP25 reference package.
2. Inspect the reference package and inventory its behavior, interfaces, parameters, imports, library calls, and other dependencies.
3. Resolve the complete dependency chain, including libraries used by other libraries.
4. Create the SOP30 package in the corresponding SOP30 directory while retaining functional equivalence.
5. Update only the SOP-specific details required by the supplied instructions and relation map.
6. Validate structure, references, naming, behavior, and dependency resolution.
7. Run the applicable ECU-TEST package PR checks and address all relevant findings.
8. Document any intentional deviation from the SOP25 reference and the requirement that justified it.

## Directory roles

- `SOP25` contains the read-only functional references for libraries and test cases.
- `SOP30` contains the newly generated SOP30 packages.
- `Instructions` contains the official help, style guide, and package relation map.

Treat SOP25 packages as source references. Unless explicitly requested, do not modify them as part of an SOP30 migration.

## Definition of done

A migrated SOP30 package is complete when:

- it is based on the correct mapped SOP25 package;
- its required library dependency chain is available and correctly referenced;
- its observable functionality matches the SOP25 reference;
- it follows the official instructions and project style guide;
- applicable PR checks pass; and
- any required deviations are traceable to an explicit SOP30 requirement.

