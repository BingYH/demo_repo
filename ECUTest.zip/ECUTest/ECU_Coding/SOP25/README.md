# SOP25 Reference Packages

This tree contains the existing SOP25 library and testcase packages used as functional references. Treat these packages as source material and do not modify them unless explicitly requested.

