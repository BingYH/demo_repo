# SOP25 Test Cases

Store SOP25 testcase `.pkg` files here. Each package is a functional reference for a mapped SOP30 testcase and may depend on multiple SOP25 libraries.

