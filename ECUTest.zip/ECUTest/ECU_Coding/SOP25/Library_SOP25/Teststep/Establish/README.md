# SOP25 Establish Test Steps

Store SOP25 test-step packages that establish connections, states, or prerequisites here.

