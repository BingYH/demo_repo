# SOP25 Set Test Steps

Store SOP25 test-step packages that set values, states, or configuration here.

