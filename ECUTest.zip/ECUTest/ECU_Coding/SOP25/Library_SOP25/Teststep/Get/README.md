# SOP25 Get Test Steps

Store SOP25 test-step packages that retrieve values, states, or results here.

