# SOP25 Library Packages

Store SOP25 reusable library `.pkg` files here, organized by function. Include all referenced libraries needed to understand transitive dependencies.

