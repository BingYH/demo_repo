# SOP25 Tooljob Libraries

Store SOP25 tooljob-related library packages here. Preserve their callable behavior and dependencies when creating mapped SOP30 packages.

