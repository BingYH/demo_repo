# SOP25 Base Libraries

Store foundational SOP25 library packages here. These packages may be shared dependencies of higher-level libraries and test cases.

