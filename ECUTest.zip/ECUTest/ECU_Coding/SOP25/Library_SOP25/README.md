# SOP25 Libraries

This directory groups reusable SOP25 library and test-step packages. Their behavior and dependency relationships provide the baseline for mapped SOP30 libraries.

