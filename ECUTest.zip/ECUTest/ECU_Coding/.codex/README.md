# Codex Configuration

Reserved for workspace-local Codex configuration. ECU-TEST package migration requirements are defined in `PROJECT_INSTRUCTIONS.md`.

