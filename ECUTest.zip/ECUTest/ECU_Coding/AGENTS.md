# Workspace Instructions

This repository creates ECU-TEST packages for the ECU Coding SOP30 scope by migrating mapped SOP25 reference packages.

Read and follow [PROJECT_INSTRUCTIONS.md](PROJECT_INSTRUCTIONS.md) before inspecting, creating, or modifying any package in this workspace. In particular:

- treat SOP25 packages as read-only references unless the user explicitly requests otherwise;
- determine every SOP30 source package from the supplied relation map;
- preserve functional equivalence and the complete transitive library dependency chain;
- do not invent new ECU-TEST elements without an explicit SOP30 requirement; and
- apply the official help, style guide, and applicable package PR checks.

If a required mapping or instruction is missing or ambiguous, ask for clarification rather than guessing.
