# SOP30 Test Cases

Store generated SOP30 testcase `.pkg` files here. Each testcase must use the mapped SOP25 package as its behavioral reference and resolve all required SOP30 library dependencies.
