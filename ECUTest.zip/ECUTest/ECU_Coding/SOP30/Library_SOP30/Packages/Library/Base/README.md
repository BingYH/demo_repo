# SOP30 Base Libraries

Store migrated foundational SOP30 libraries here. Verify functional equivalence before dependent packages are validated.

