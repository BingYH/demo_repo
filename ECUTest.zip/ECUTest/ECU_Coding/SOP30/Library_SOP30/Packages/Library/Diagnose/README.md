# SOP30 Diagnose Libraries

Store migrated SOP30 diagnostic libraries here. Preserve the observable behavior of their mapped SOP25 references.

