# SOP30 Get Test Steps

Store migrated SOP30 test steps that retrieve values, states, or results here.

