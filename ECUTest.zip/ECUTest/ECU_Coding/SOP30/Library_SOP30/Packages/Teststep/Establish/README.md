# SOP30 Establish Test Steps

Store migrated SOP30 test steps that establish connections, states, or prerequisites here.

