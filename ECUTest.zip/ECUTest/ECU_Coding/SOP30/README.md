# SOP30 Target Packages

This tree contains SOP30 packages generated from mapped SOP25 references. New packages must remain functionally equivalent and pass the applicable ECU-TEST PR checks.

