# Instructions

Authoritative migration inputs belong here: official ECU-TEST help, the project test style guide, and the SOP25-to-SOP30 relation map. Review all relevant guidance before generating a package.

