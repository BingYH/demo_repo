# SOP25-to-SOP30 Relation Map

Place the explicit mapping between each SOP30 target package and its SOP25 reference package here. A migration must not start until its mapping is unambiguous.

