# Test Style Guide

Place project conventions for ECU-TEST package structure, naming, documentation, and quality here. Generated SOP30 packages must conform to this guidance.

